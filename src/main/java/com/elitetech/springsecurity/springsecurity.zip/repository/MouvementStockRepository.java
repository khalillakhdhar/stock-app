package com.elitetech.springsecurity.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MouvementStockRepository extends JpaRepository<com.elitetech.springsecurity.entity.MouvementStock, Long> {

}
