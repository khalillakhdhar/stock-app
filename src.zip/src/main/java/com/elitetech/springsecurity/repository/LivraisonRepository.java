package com.elitetech.springsecurity.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.elitetech.springsecurity.entity.Livraison;

public interface LivraisonRepository extends JpaRepository<Livraison, Long> {

}
